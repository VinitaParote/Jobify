import React from 'react'

const DeleteJob = () => {
  return (
    <h1>DeleteJob page</h1>
  )
}

export default DeleteJob;