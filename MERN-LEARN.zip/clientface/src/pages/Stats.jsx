import React from 'react'

const Stats = () => {
  return (
    <h1>Stats page</h1>
  )
}

export default Stats;