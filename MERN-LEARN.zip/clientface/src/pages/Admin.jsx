import React from 'react'

const Admin = () => {
  return (
    <h1>Admin page</h1>
  )
}

export default Admin