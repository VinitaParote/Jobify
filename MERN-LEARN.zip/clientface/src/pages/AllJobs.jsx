import React from 'react'

const AllJobs = () => {
  return (
    <h1>AllJobs page</h1>
  )
}

export default AllJobs;