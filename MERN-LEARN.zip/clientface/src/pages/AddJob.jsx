import React from 'react'

const AddJob = () => {
  return (
    <h1>AddJob page</h1>
  )
}

export default AddJob